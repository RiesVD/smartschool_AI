const loginBtn = document.getElementById('loginBtn');
const passwordToggle = document.getElementById('passwordToggle');
const passwordInput = document.getElementById('password');
const usernameInput = document.getElementById('username');
const errorMessage = document.getElementById('errorMessage');
const errorText = document.getElementById('errorText');
const eyeIcon = document.getElementById('eyeIcon');

passwordToggle.addEventListener('click', () => {
    const isPassword = passwordInput.type === 'password';
    passwordInput.type = isPassword ? 'text' : 'password';
    eyeIcon.innerHTML = isPassword
        ? `<path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/><line x1="1" y1="1" x2="23" y2="23"/>`
        : `<path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/>`;
});

[usernameInput, passwordInput].forEach(input => {
    input.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') loginBtn.click();
    });
});

[usernameInput, passwordInput].forEach(input => {
    input.addEventListener('input', () => {
        errorMessage.classList.remove('show');
    });
});

loginBtn.addEventListener('click', () => {
    const username = usernameInput.value.trim();
    const password = passwordInput.value;

    if (!username || !password) {
        errorText.textContent = 'Please fill in all fields.';
        errorMessage.classList.add('show');
        return;
    }

    loginBtn.classList.add('loading');
    loginBtn.textContent = 'Signing in…';

    setTimeout(() => {
        window.location.href = 'analysis_tool.html';
    }, 1200);
});

document.getElementById('smartschoolBtn').addEventListener('click', () => {
    window.location.href = 'analysis_tool.html';
});